package com.zzhoujay.richtext.parser;

import android.graphics.drawable.Drawable;

/**
 * Created by zhou on 2016/12/3.
 * ImageGetterWrapper
 */

public interface ImageGetterWrapper {

    Drawable getDrawable(String source);

}
