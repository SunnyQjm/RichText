package com.zzhoujay.richtext.parser;

import android.text.Spanned;

/**
 * Created by zhou on 16-7-27.
 * SpannedParser
 */
public interface SpannedParser {

    Spanned parse(String source);

}
