package com.zzhoujay.richtext.callback;

import com.zzhoujay.richtext.LinkHolder;

/**
 * Created by zhou on 2016/11/17.
 * LinkFixCallback
 */
public interface LinkFixCallback {

    void fix(LinkHolder holder);

}
