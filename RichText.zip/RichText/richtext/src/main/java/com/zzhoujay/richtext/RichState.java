package com.zzhoujay.richtext;

/**
 * Created by zhou on 16-10-24.
 * Image Load State
 */
public enum RichState {
    ready, loading, loaded
}
