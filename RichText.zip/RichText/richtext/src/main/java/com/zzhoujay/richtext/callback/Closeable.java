package com.zzhoujay.richtext.callback;

import java.io.IOException;

/**
 * Created by zhou on 2017/11/17.
 */

public interface Closeable {

    void close() throws IOException;

}
