package com.zzhoujay.richtext.spans;

import android.view.View;

/**
 * Created by zhou on 2016/11/17.
 * Clickable
 */
@SuppressWarnings("WeakerAccess")
public interface Clickable {

    void onClick(View widget);

}
