package com.zzhoujay.richtext.spans;

/**
 * Created by zhou on 16-8-4.
 * LongClickableSpan
 */
public interface LongClickableSpan extends Clickable, LongClickable {
}
