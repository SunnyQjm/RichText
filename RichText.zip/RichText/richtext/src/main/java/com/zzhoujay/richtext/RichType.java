package com.zzhoujay.richtext;

/**
 * Created by zhou on 16-7-27.
 * 富文本类型
 */
public enum RichType {
    html, markdown
}
