package com.zzhoujay.richtext.callback;

/**
 * Created by zhou on 2016/12/4.
 * 标记为可回收的
 */
public interface Recyclable {

    /**
     * 回收资源
     */
    void recycle();

}
